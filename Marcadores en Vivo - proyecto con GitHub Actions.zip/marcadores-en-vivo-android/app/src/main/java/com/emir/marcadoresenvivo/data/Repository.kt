package com.emir.marcadoresenvivo.data

/** Descarga los partidos del día de una liga desde ESPN. */
class ScoreRepository(private val api: EspnApi = EspnApi.create()) {

    suspend fun getGames(league: League): List<Game> {
        val response = when (league) {
            League.NBA -> api.nbaScoreboard()
            League.LALIGA -> api.laLigaScoreboard()
            League.CHAMPIONS -> api.championsScoreboard()
        }
        return response.events.mapNotNull { it.toGame(league) }
    }

    /** Descarga las tres ligas (las que fallen devuelven lista vacía). */
    suspend fun getAllGames(): Map<League, List<Game>> {
        return League.values().associateWith { league ->
            runCatching { getGames(league) }.getOrDefault(emptyList())
        }
    }
}
