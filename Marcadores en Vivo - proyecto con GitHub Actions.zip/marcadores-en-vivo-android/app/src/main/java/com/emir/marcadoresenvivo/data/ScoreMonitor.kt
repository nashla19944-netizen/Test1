package com.emir.marcadoresenvivo.data

/**
 * Detecta qué equipos seguidos anotaron comparando con el último
 * marcador guardado. Lo usan tanto la app en primer plano como el
 * trabajo en segundo plano (WorkManager), para no avisar dos veces.
 */
object ScoreMonitor {

    data class ScoreEvent(
        val game: Game,
        /** Abreviatura del equipo que anotó, o "" si no se sabe cuál fue. */
        val scorerAbbr: String,
        val scorerName: String,
        val homeScore: Int,
        val awayScore: Int
    )

    /**
     * Devuelve un evento por cada equipo seguido cuyo marcador subió
     * respecto a [lastScores]. Si no había marcador guardado, no avisa
     * (primera carga) y solo registra el estado actual.
     */
    fun detectScoreEvents(
        games: List<Game>,
        followed: Set<String>,
        lastScores: Map<String, String>
    ): List<ScoreEvent> {
        if (lastScores.isEmpty()) return emptyList()
        val events = mutableListOf<ScoreEvent>()
        for (game in games) {
            val home = game.homeScore ?: continue
            val away = game.awayScore ?: continue
            val previous = lastScores[game.id] ?: continue
            val prevParts = previous.split("-").mapNotNull { it.toIntOrNull() }
            if (prevParts.size != 2) continue
            val (prevHome, prevAway) = prevParts
            if (home <= prevHome && away <= prevAway) continue
            // ¿Quién anotó?
            val (scorerAbbr, scorerName) = when {
                home > prevHome && game.homeAbbr in followed ->
                    game.homeAbbr to game.homeShort.ifBlank { game.homeName }
                away > prevAway && game.awayAbbr in followed ->
                    game.awayAbbr to game.awayShort.ifBlank { game.awayName }
                game.homeAbbr in followed || game.awayAbbr in followed -> {
                    // Subió el marcador y un equipo seguido juega: avisar igual.
                    if (home > prevHome) game.homeAbbr to game.homeShort.ifBlank { game.homeName }
                    else game.awayAbbr to game.awayShort.ifBlank { game.awayName }
                }
                else -> continue
            }
            events += ScoreEvent(game, scorerAbbr, scorerName, home, away)
        }
        return events
    }

    /** Texto de la notificación en español, como pediste. */
    fun notificationText(event: ScoreEvent): Pair<String, String> {
        val game = event.game
        val verb = if (game.league.isSoccer) "¡Gol!" else "¡Canasta!"
        val title = "$verb ${event.scorerName}"
        val scoreLine = "${game.homeShort.ifBlank { game.homeName }} ${event.homeScore}-${event.awayScore} ${game.awayShort.ifBlank { game.awayName }}"
        val body = if (game.detail.isNotBlank()) {
            "$scoreLine · ${game.detail}"
        } else {
            scoreLine
        }
        return title to body
    }
}
