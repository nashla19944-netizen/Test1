package com.emir.marcadoresenvivo.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.emir.marcadoresenvivo.data.FollowStore
import com.emir.marcadoresenvivo.data.Game
import com.emir.marcadoresenvivo.data.League
import com.emir.marcadoresenvivo.data.ScoreMonitor
import com.emir.marcadoresenvivo.data.ScoreRepository
import com.emir.marcadoresenvivo.notifications.NotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ScoresUiState(
    val games: Map<League, List<Game>> = emptyMap(),
    val isRefreshing: Boolean = false,
    val error: String? = null,
    val followed: Set<String> = emptySet(),
    val lastUpdated: Long = 0L
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ScoreRepository()
    private val followStore = FollowStore(application)

    private val _uiState = MutableStateFlow(
        ScoresUiState(followed = followStore.getFollowed())
    )
    val uiState: StateFlow<ScoresUiState> = _uiState.asStateFlow()

    init {
        refresh()
        // Auto-actualización cada 30 segundos mientras la app está abierta.
        viewModelScope.launch {
            while (true) {
                delay(30_000)
                refresh(silent = true)
            }
        }
    }

    fun refresh(silent: Boolean = false) {
        viewModelScope.launch {
            if (!silent) _uiState.update { it.copy(isRefreshing = true, error = null) }
            try {
                val games = repository.getAllGames()
                checkFollowedScores(games.values.flatten())
                _uiState.update {
                    it.copy(
                        games = games,
                        isRefreshing = false,
                        error = null,
                        lastUpdated = System.currentTimeMillis()
                    )
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isRefreshing = false,
                        error = "No se pudo actualizar. Revisa tu conexión e inténtalo de nuevo."
                    )
                }
            }
        }
    }

    /** En primer plano también avisa cuando un equipo seguido anota. */
    private fun checkFollowedScores(games: List<Game>) {
        val followed = followStore.getFollowed()
        val lastScores = followStore.getLastScores()
        val events = ScoreMonitor.detectScoreEvents(games, followed, lastScores)
        for (event in events) {
            val (title, body) = ScoreMonitor.notificationText(event)
            NotificationHelper.showScoreNotification(
                getApplication(),
                event.game.id.hashCode(),
                title,
                body
            )
        }
        val current = games.associate { it.id to "${it.homeScore ?: 0}-${it.awayScore ?: 0}" }
        followStore.saveLastScores(current)
    }

    fun toggleFollow(abbr: String) {
        followStore.toggleFollow(abbr)
        _uiState.update { it.copy(followed = followStore.getFollowed()) }
    }

    fun isFollowed(abbr: String): Boolean = abbr in _uiState.value.followed
}
