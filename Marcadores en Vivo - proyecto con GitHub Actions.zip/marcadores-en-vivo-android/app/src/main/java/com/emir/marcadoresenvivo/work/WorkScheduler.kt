package com.emir.marcadoresenvivo.work

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object WorkScheduler {
    const val WORK_NAME = "score-check"

    /** Programa la revisión cada 15 minutos (mínimo que permite Android). */
    fun schedule(context: Context) {
        val request = PeriodicWorkRequestBuilder<ScoreCheckWorker>(15, TimeUnit.MINUTES)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build()
            )
            .build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }
}

/** Al reiniciar el teléfono, WorkManager vuelve a programar el trabajo solo,
 *  pero este receptor garantiza que se programe aunque algo lo haya quitado. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            WorkScheduler.schedule(context)
        }
    }
}
