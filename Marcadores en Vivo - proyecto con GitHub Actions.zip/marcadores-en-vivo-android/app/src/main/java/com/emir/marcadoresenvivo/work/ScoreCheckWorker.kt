package com.emir.marcadoresenvivo.work

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.emir.marcadoresenvivo.data.FollowStore
import com.emir.marcadoresenvivo.data.ScoreMonitor
import com.emir.marcadoresenvivo.data.ScoreRepository
import com.emir.marcadoresenvivo.notifications.NotificationHelper

/**
 * Revisa los marcadores en segundo plano. Android solo permite
 * trabajo periódico cada 15 minutos como mínimo, así que los avisos
 * pueden tardar hasta 15 minutos: no es instantáneo al segundo,
 * igual que pasaba con los avisos del chat.
 */
class ScoreCheckWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val store = FollowStore(applicationContext)
        val followed = store.getFollowed()
        if (followed.isEmpty()) return Result.success()
        val lastScores = store.getLastScores()
        return try {
            val games = ScoreRepository().getAllGames().values.flatten()
            val events = ScoreMonitor.detectScoreEvents(games, followed, lastScores)
            for (event in events) {
                val (title, body) = ScoreMonitor.notificationText(event)
                NotificationHelper.showScoreNotification(
                    applicationContext,
                    event.game.id.hashCode(),
                    title,
                    body
                )
            }
            // Guardar el marcador actual para la próxima revisión.
            val current = games.associate { game ->
                game.id to "${game.homeScore ?: 0}-${game.awayScore ?: 0}"
            }
            store.saveLastScores(current)
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }
}
