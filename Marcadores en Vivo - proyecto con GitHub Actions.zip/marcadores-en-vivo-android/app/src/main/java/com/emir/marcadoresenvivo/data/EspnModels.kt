package com.emir.marcadoresenvivo.data

import com.google.gson.annotations.SerializedName

/**
 * Respuesta del marcador público de ESPN (sin clave de API):
 * https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard
 * https://site.api.espn.com/apis/site/v2/sports/soccer/esp.1/scoreboard
 * https://site.api.espn.com/apis/site/v2/sports/soccer/uefa.champions/scoreboard
 */
data class ScoreboardResponse(
    @SerializedName("events") val events: List<EspnEvent> = emptyList()
)

data class EspnEvent(
    @SerializedName("id") val id: String = "",
    @SerializedName("name") val name: String = "",
    @SerializedName("date") val date: String = "",
    @SerializedName("status") val status: EspnStatus? = null,
    @SerializedName("competitions") val competitions: List<EspnCompetition> = emptyList()
)

data class EspnStatus(
    @SerializedName("type") val type: EspnStatusType? = null,
    @SerializedName("period") val period: Int = 0,
    @SerializedName("displayClock") val displayClock: String? = null
)

data class EspnStatusType(
    /** "pre" (no empezó), "in" (en vivo), "post" (terminado) */
    @SerializedName("state") val state: String = "",
    /** Ej. "Q4 10:21" en NBA, "65'" en fútbol, "Final" */
    @SerializedName("detail") val detail: String = "",
    @SerializedName("shortDetail") val shortDetail: String = ""
)

data class EspnCompetition(
    @SerializedName("competitors") val competitors: List<EspnCompetitor> = emptyList()
)

data class EspnCompetitor(
    @SerializedName("homeAway") val homeAway: String = "",
    @SerializedName("score") val score: String? = null,
    @SerializedName("team") val team: EspnTeam? = null
)

data class EspnTeam(
    @SerializedName("displayName") val displayName: String = "",
    @SerializedName("shortDisplayName") val shortDisplayName: String = "",
    @SerializedName("abbreviation") val abbreviation: String = "",
    @SerializedName("logo") val logo: String? = null,
    @SerializedName("color") val color: String? = null
)

/** Ligas que muestra la app. */
enum class League(val title: String, val isSoccer: Boolean) {
    NBA("NBA", false),
    LALIGA("LaLiga", true),
    CHAMPIONS("Champions", true)
}

/** Modelo de dominio que usa la interfaz. */
data class Game(
    val id: String,
    val league: League,
    val homeName: String,
    val homeShort: String,
    val homeAbbr: String,
    val homeScore: Int?,
    val homeLogo: String?,
    val awayName: String,
    val awayShort: String,
    val awayAbbr: String,
    val awayScore: Int?,
    val awayLogo: String?,
    /** "pre", "in" o "post" */
    val state: String,
    /** Ej. "Q4 10:21", "65'", "Final", "Hoy, 19:00" */
    val detail: String,
    val period: Int,
    val date: String
) {
    val isLive: Boolean get() = state == "in"
    val isFinished: Boolean get() = state == "post"
    val scoreText: String get() = "${homeScore ?: "-"} - ${awayScore ?: "-"}"
}

/** Convierte un evento de ESPN en un [Game]. */
fun EspnEvent.toGame(league: League): Game? {
    val competition = competitions.firstOrNull() ?: return null
    val home = competition.competitors.firstOrNull { it.homeAway == "home" } ?: return null
    val away = competition.competitors.firstOrNull { it.homeAway == "away" } ?: return null
    return Game(
        id = id,
        league = league,
        homeName = home.team?.displayName.orEmpty(),
        homeShort = home.team?.shortDisplayName.orEmpty(),
        homeAbbr = home.team?.abbreviation.orEmpty(),
        homeScore = home.score?.toIntOrNull(),
        homeLogo = home.team?.logo,
        awayName = away.team?.displayName.orEmpty(),
        awayShort = away.team?.shortDisplayName.orEmpty(),
        awayAbbr = away.team?.abbreviation.orEmpty(),
        awayScore = away.score?.toIntOrNull(),
        awayLogo = away.team?.logo,
        state = status?.type?.state.orEmpty(),
        detail = status?.type?.shortDetail?.takeIf { it.isNotBlank() }
            ?: status?.type?.detail.orEmpty(),
        period = status?.period ?: 0,
        date = date
    )
}
