package com.emir.marcadoresenvivo

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.emir.marcadoresenvivo.data.Game
import com.emir.marcadoresenvivo.data.League
import com.emir.marcadoresenvivo.notifications.NotificationHelper
import com.emir.marcadoresenvivo.ui.GameDetailScreen
import com.emir.marcadoresenvivo.ui.GameListScreen
import com.emir.marcadoresenvivo.ui.MainViewModel
import com.emir.marcadoresenvivo.ui.theme.MarcadoresEnVivoTheme
import com.emir.marcadoresenvivo.work.WorkScheduler

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* El usuario decide; sin permiso no hay avisos en segundo plano. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        NotificationHelper.createChannel(this)
        WorkScheduler.schedule(this)
        requestNotificationPermissionIfNeeded()

        setContent {
            MarcadoresEnVivoTheme {
                ScoresApp(viewModel = viewModel)
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScoresApp(viewModel: MainViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var selectedGame by remember { mutableStateOf<Game?>(null) }
    val leagues = League.values()

    Scaffold(
        topBar = { TopAppBar(title = { Text("Marcadores en Vivo") }) }
    ) { padding ->
        if (selectedGame != null) {
            GameDetailScreen(
                game = selectedGame!!,
                onBack = { selectedGame = null },
                modifier = Modifier.padding(padding)
            )
            return@Scaffold
        }
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = selectedTab) {
                leagues.forEachIndexed { index, league ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(league.title) }
                    )
                }
            }
            val league = leagues[selectedTab]
            val games = uiState.games[league].orEmpty()
            PullToRefreshBox(
                isRefreshing = uiState.isRefreshing,
                onRefresh = { viewModel.refresh() },
                modifier = Modifier.fillMaxSize()
            ) {
                Column(Modifier.fillMaxSize()) {
                    if (uiState.error != null) {
                        Text(
                            text = uiState.error!!,
                            modifier = Modifier.padding(16.dp)
                        )
                    }
                    GameListScreen(
                        games = games,
                        followed = uiState.followed,
                        onToggleFollow = { viewModel.toggleFollow(it) },
                        onGameClick = { selectedGame = it },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }
        }
    }
}
