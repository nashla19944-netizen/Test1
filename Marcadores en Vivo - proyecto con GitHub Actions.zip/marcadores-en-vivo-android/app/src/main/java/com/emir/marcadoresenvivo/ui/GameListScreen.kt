package com.emir.marcadoresenvivo.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.emir.marcadoresenvivo.data.Game

@Composable
fun GameListScreen(
    games: List<Game>,
    followed: Set<String>,
    onToggleFollow: (String) -> Unit,
    onGameClick: (Game) -> Unit,
    modifier: Modifier = Modifier
) {
    if (games.isEmpty()) {
        Column(
            modifier = modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("No hay partidos hoy en esta liga.", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
            Text(
                "Desliza hacia abajo para actualizar.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        return
    }
    LazyColumn(modifier = modifier.fillMaxSize()) {
        items(games, key = { it.id }) { game ->
            GameCard(
                game = game,
                followed = followed,
                onToggleFollow = onToggleFollow,
                onGameClick = onGameClick
            )
        }
    }
}

@Composable
fun GameCard(
    game: Game,
    followed: Set<String>,
    onToggleFollow: (String) -> Unit,
    onGameClick: (Game) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .clickable { onGameClick(game) },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (game.isLive) "● EN VIVO" else game.detail.ifBlank { "Por jugar" },
                    style = MaterialTheme.typography.labelMedium,
                    color = if (game.isLive) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.Bold
                )
                if (game.isLive || game.isFinished) {
                    Text(
                        text = game.detail,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            TeamRow(
                name = game.homeShort.ifBlank { game.homeName },
                score = game.homeScore,
                isFollowed = game.homeAbbr in followed,
                onToggleFollow = { onToggleFollow(game.homeAbbr) }
            )
            TeamRow(
                name = game.awayShort.ifBlank { game.awayName },
                score = game.awayScore,
                isFollowed = game.awayAbbr in followed,
                onToggleFollow = { onToggleFollow(game.awayAbbr) }
            )
            if (game.isFinished) {
                Spacer(Modifier.height(4.dp))
                Text("Final", style = MaterialTheme.typography.labelMedium)
            }
        }
    }
}

@Composable
private fun TeamRow(
    name: String,
    score: Int?,
    isFollowed: Boolean,
    onToggleFollow: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onToggleFollow) {
                Icon(
                    imageVector = if (isFollowed) Icons.Filled.Star else Icons.Outlined.StarBorder,
                    contentDescription = if (isFollowed) "Dejar de seguir a $name" else "Seguir a $name",
                    tint = if (isFollowed) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
        }
        Text(
            text = score?.toString() ?: "-",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
    }
}

/** Vista de detalle de un partido: marcador, estado y periodo. */
@Composable
fun GameDetailScreen(game: Game, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = when (game.league) {
                com.emir.marcadoresenvivo.data.League.NBA -> "NBA"
                com.emir.marcadoresenvivo.data.League.LALIGA -> "LaLiga"
                com.emir.marcadoresenvivo.data.League.CHAMPIONS -> "Champions League"
            },
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        Spacer(Modifier.height(16.dp))
        Text(game.homeName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("vs", style = MaterialTheme.typography.bodyLarge)
        Text(game.awayName, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Text(
            text = game.scoreText,
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(16.dp))
        Text("Estado: ${game.detail.ifBlank { "Por jugar" }}")
        Text("Periodo: ${if (game.period > 0) game.period.toString() else "-"}")
        Text("En vivo: ${if (game.isLive) "sí" else "no"}")
        Text("Terminado: ${if (game.isFinished) "sí" else "no"}")
        Spacer(Modifier.height(24.dp))
        androidx.compose.material3.Button(onClick = onBack) {
            Text("Volver")
        }
    }
}
