package com.emir.marcadoresenvivo.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Equipos seguidos, guardados por abreviatura (estable en ESPN).
 * Por defecto: Lakers (LAL) en NBA, Real Madrid (RMA) y Barcelona (BAR).
 */
class FollowStore(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("marcadores_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_FOLLOWED = "followed_teams"
        private const val KEY_LAST_SCORES = "last_scores"
        val DEFAULT_FOLLOWED: Set<String> = setOf("LAL", "RMA", "BAR")
    }

    fun getFollowed(): Set<String> =
        prefs.getStringSet(KEY_FOLLOWED, null) ?: DEFAULT_FOLLOWED

    fun isFollowed(abbr: String): Boolean = abbr in getFollowed()

    fun toggleFollow(abbr: String) {
        val current = getFollowed().toMutableSet()
        if (abbr in current) current.remove(abbr) else current.add(abbr)
        prefs.edit().putStringSet(KEY_FOLLOWED, current).apply()
    }

    // --- Últimos marcadores conocidos, para detectar que un equipo anotó ---
    /** Mapa gameId -> "golesLocal-golesVisitante", ej. "91-77". */
    fun getLastScores(): Map<String, String> {
        val raw = prefs.getString(KEY_LAST_SCORES, "") ?: ""
        if (raw.isBlank()) return emptyMap()
        return raw.split(";").mapNotNull {
            val parts = it.split("=")
            if (parts.size == 2) parts[0] to parts[1] else null
        }.toMap()
    }

    fun saveLastScores(scores: Map<String, String>) {
        val raw = scores.entries.joinToString(";") { "${it.key}=${it.value}" }
        prefs.edit().putString(KEY_LAST_SCORES, raw).apply()
    }
}
