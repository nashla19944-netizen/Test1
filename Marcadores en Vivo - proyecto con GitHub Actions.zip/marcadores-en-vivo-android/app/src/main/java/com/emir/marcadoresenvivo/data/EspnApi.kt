package com.emir.marcadoresenvivo.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

/**
 * API pública de marcadores de ESPN. No necesita clave.
 * Base: https://site.api.espn.com/apis/site/v2/sports/
 */
interface EspnApi {
    @GET("basketball/nba/scoreboard")
    suspend fun nbaScoreboard(): ScoreboardResponse

    @GET("soccer/esp.1/scoreboard")
    suspend fun laLigaScoreboard(): ScoreboardResponse

    @GET("soccer/uefa.champions/scoreboard")
    suspend fun championsScoreboard(): ScoreboardResponse

    companion object {
        fun create(): EspnApi {
            val retrofit = Retrofit.Builder()
                .baseUrl("https://site.api.espn.com/apis/site/v2/sports/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
            return retrofit.create(EspnApi::class.java)
        }
    }
}
