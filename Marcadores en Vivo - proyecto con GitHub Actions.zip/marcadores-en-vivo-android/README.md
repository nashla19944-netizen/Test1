# Marcadores en Vivo

Aplicación Android que muestra los marcadores en vivo de la **NBA, LaLiga y la Champions League**,
y te avisa con una notificación cada vez que un equipo que sigues anota.

- **Interfaz en español.**
- **Sin clave de API:** usa el marcador público de ESPN.
- **Seguir equipos:** toca la estrella junto a un equipo. Por defecto ya sigues a los **Lakers**,
  al **Real Madrid** y al **Barcelona**.
- **Notificaciones en español**, por ejemplo:
  - `¡Gol! Real Madrid 2-1 Barcelona · 65'`
  - `¡Canasta! Lakers 91-77 Portland · Q4 10:21`
- **Actualización en la app:** cada 30 segundos mientras está abierta, y deslizando hacia abajo.

## Cómo funciona

| Parte | Tecnología |
|---|---|
| Interfaz | Kotlin + Jetpack Compose + Material 3 |
| Datos | Retrofit + Gson contra `site.api.espn.com` (NBA, `esp.1`, `uefa.champions`) |
| Fondo | WorkManager, revisión periódica cada 15 minutos |
| Notificaciones | Canal `Marcadores en vivo`, permiso `POST_NOTIFICATIONS` (Android 13+) |

## Sobre las notificaciones en tiempo real

**Android no permite avisar al segundo exacto en segundo plano.** El sistema solo deja
programar trabajo periódico cada **15 minutos como mínimo** (WorkManager). Eso quiere decir:

- Con la app **abierta**, los marcadores se actualizan cada **30 segundos** y el aviso sale casi al momento.
- Con la app **cerrada**, el aviso puede tardar **hasta 15 minutos** desde que se anotó el gol o la canasta.
- Es la misma limitación que tenían los avisos del chat: son revisiones periódicas, no una
  transmisión en vivo continua.

Para que lleguen los avisos, acepta el permiso de notificaciones la primera vez que abras la app.

## Cómo abrirla en Android Studio

1. Abre **Android Studio** (Hedgehog o más reciente).
2. Elige **Open** y selecciona la carpeta `marcadores-en-vivo-android`.
3. Deja que Gradle sincronice el proyecto (descarga las dependencias la primera vez).
4. Conecta tu teléfono Android por USB con la depuración activada, o crea un emulador
   (API 34 o más reciente).
5. Pulsa **Run ▶**.

Requisitos: JDK 17, Android SDK con `compileSdk 35`, `minSdk 26` y `targetSdk 34`.

## Cómo compilar el APK desde la terminal

```bash
export ANDROID_HOME=$HOME/Android/Sdk   # ruta de tu SDK
./gradlew assembleDebug
```

El APK queda en:

```
app/build/outputs/apk/debug/app-debug.apk
```

Pásalo a tu teléfono y ábrelo para instalarlo (permite instalar desde esa fuente si te lo pide).
En un teléfono con Android 14+, el APK de depuración se instala sin firmar para pruebas.

## Estructura del proyecto

```
marcadores-en-vivo-android/
├── README.md
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/emir/marcadoresenvivo/
        │   ├── MainActivity.kt            # Pestañas NBA / LaLiga / Champions
        │   ├── data/
        │   │   ├── EspnModels.kt          # Modelos del marcador de ESPN
        │   │   ├── EspnApi.kt             # Endpoints de ESPN (sin clave)
        │   │   ├── Repository.kt          # Descarga los partidos
        │   │   ├── FollowStore.kt         # Equipos seguidos y últimos marcadores
        │   │   └── ScoreMonitor.kt        # Detecta quién anotó y arma el texto
        │   ├── notifications/
        │   │   └── NotificationHelper.kt  # Canal "Marcadores en vivo"
        │   ├── work/
        │   │   ├── ScoreCheckWorker.kt    # Revisión en segundo plano
        │   │   └── WorkScheduler.kt       # Programa cada 15 min + BootReceiver
        │   └── ui/
        │       ├── MainViewModel.kt       # Estado y auto-actualización (30 s)
        │       ├── GameListScreen.kt      # Lista de partidos y detalle
        │       └── theme/Theme.kt
        └── res/values/strings.xml, themes.xml, drawable/ic_notification.xml
```

## Privacidad

La app solo consulta marcadores públicos de ESPN. No pide cuenta, no guarda contraseñas
y no envía tus datos a ningún servidor propio: los equipos seguidos se guardan solo en tu teléfono.

## Versión

v1.0 — Pestañas NBA / LaLiga / Champions, seguir equipos, detalle de partido,
notificaciones de gol/canasta.

## Nota sobre compilar en esta computadora

En la computadora donde se creó el proyecto no se pudo producir el APK: Gradle
necesita comunicarse con su proceso de compilación por TCP local y ese permiso
está desactivado en este entorno, así que el proceso de Gradle se desconecta
al arrancar (`Could not receive a message from the daemon`). El proyecto está
completo y listo: ábrelo en Android Studio en una computadora normal (o activa
el permiso de red local) y compila con `./gradlew assembleDebug` sin cambios.

El código Kotlin se validó con el compilador kotlinc 2.0.21 contra las
librerías reales (Retrofit, WorkManager, Lifecycle, Compose/Material 3): la
revisión de tipos pasa sin errores en los 13 archivos. Durante esa validación
se corrigió un error real en `FollowStore.kt` (`const val` fuera del
`companion object`).
